from web_checker import check_url_status

res = check_url_status("https://www.icintracom.com.mx/nosotros")
print(res)
