from screenshot_manager import enviar_y_borrar_screenshots

# Parámetros de prueba
client = "Chantilly"
screenshot_dir = "./screenshots/Chantilly"
url = "https://www.grupochantilly.com.mx"

# Ejecutar función de envío y borrado
enviar_y_borrar_screenshots(client, screenshot_dir, url)