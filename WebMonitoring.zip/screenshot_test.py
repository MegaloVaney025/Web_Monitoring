from screenshot_module import take_screenshot

url = "https://expired.badssl.com/"
output_path = "test_ssl_expired.png"

take_screenshot(url, output_path)
