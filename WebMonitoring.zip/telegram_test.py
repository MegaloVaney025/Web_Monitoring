from telegram_module import send_telegram_message

send_telegram_message("Hola Camila.")