# config.py
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # carpeta donde está config.py

SCREENSHOTS_BASE_DIR = os.path.join(BASE_DIR, "screenshots")
LOGS_BASE_DIR = os.path.join(BASE_DIR, "logs")

# Clientes y su configuración individual
CLIENTS = {
    "Chantilly": {
        "urls": [
            "https://www.grupochantilly.com.mx"
        ],
        "teams_webhook": "https://creixaconsulting.webhook.office.com/webhookb2/eebd4a74-3bc2-4930-850d-a4c1a47501e5@96281941-5ce1-4706-a20d-58c2e9c6660e/IncomingWebhook/d34bc2e5215d4b83b9117a26c1c98278/84565290-ade6-4deb-9c92-587758f3f1f8/V2NJ8GLudf6dBYCZYUKh4F86U5ZGx-fg5P7O-WxoIkFFw1",
        "log_dir": os.path.join(LOGS_BASE_DIR, "Chantilly"),
        "screenshot_dir": os.path.join(SCREENSHOTS_BASE_DIR, "Chantilly"),
    },
    "ICIntracom": {
        "urls": [
            "https://www.icintracom.com.mx/nosotros"
        ],
        "teams_webhook": "https://creixaconsulting.webhook.office.com/webhookb2/5897d667-c0c4-4a88-b04d-a2d26780d51d@96281941-5ce1-4706-a20d-58c2e9c6660e/IncomingWebhook/91915c51a3ab4c23ad40b8f42d9d86b0/84565290-ade6-4deb-9c92-587758f3f1f8/V2wjfvP1qq2QtqMdcM3_QqgflVsNP6DLsNSiRyaFHFcFo1",
        "log_dir": os.path.join(LOGS_BASE_DIR, "ICIntracom"),
        "screenshot_dir": os.path.join(SCREENSHOTS_BASE_DIR, "ICIntracom"),
    },
}

# Config general
NORMAL_CHECK_INTERVAL = 3600  # segundos
ALERT_CHECK_INTERVAL = 30
SSL_ALERT_DAYS = 7

# Telegram (común para todos)
TELEGRAM_BOT_TOKEN = "8099712485:AAGbAKU865PT7PFULLhbIrF4mZlAgIQ1yfA"
TELEGRAM_CHAT_ID = "1678510199"